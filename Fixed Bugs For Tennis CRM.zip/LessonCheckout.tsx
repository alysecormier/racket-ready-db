import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment } from "@/lib/stripe";
import { createLessonBookingCheckout } from "@/lib/booking.functions";

interface LessonCheckoutProps {
  lessonId: string;
  studentId?: string | null;
  returnUrl?: string;
  stayForMatchPlay?: boolean;
}

export function LessonCheckout({
  lessonId,
  studentId,
  returnUrl,
  stayForMatchPlay,
}: LessonCheckoutProps) {
  const fetchClientSecret = async (): Promise<string> => {
    // Build a safe fallback return URL — guard against empty origin
    const origin =
      typeof window !== "undefined" && window.location.origin
        ? window.location.origin
        : "";

    if (!origin && !returnUrl) {
      throw new Error("Cannot determine return URL: window.location.origin is unavailable");
    }

    const resolvedReturnUrl =
      returnUrl ||
      `${origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`;

    const secret = await createLessonBookingCheckout({
      data: {
        lessonId,
        studentId: studentId ?? null,
        returnUrl: resolvedReturnUrl,
        environment: getStripeEnvironment(),
        stayForMatchPlay: stayForMatchPlay === true,
      },
    });

    if (!secret) throw new Error("Failed to start checkout session");
    return secret;
  };

  return (
    <div id="checkout" className="min-h-[600px]">
      <EmbeddedCheckoutProvider
        stripe={getStripe()}
        options={{ fetchClientSecret }}
      >
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}
