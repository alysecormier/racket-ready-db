import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { z } from "zod";
import {
  CheckCircle2, AlertTriangle, Plus, Trash2, CalendarDays,
  Users, DollarSign, LayoutGrid, CalendarRange, LogOut, Pencil,
  ChevronLeft, ChevronRight,
} from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { LessonCheckout } from "@/components/LessonCheckout";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { useServerFn } from "@tanstack/react-start";
import { signWaiver } from "@/lib/waiver.functions";
import { cancelMyBooking } from "@/lib/cancel.functions";
import { getMatchPlayRoster } from "@/lib/match-play.functions";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Get Started — Ace Tennis Academy" },
      { name: "description", content: "Join Ace Tennis Academy in a few simple steps." },
    ],
  }),
  component: OnboardingPage,
});

type Child = { name: string; age: string; gender: string };
type Student = { id: string; name: string; age: number | null; gender: string | null };
type Lesson = {
  id: string; title: string; start_time: string; end_time: string;
  capacity: number; price: number; booked: number; lesson_type?: string | null;
};
type Booking = {
  id: string; lesson_id: string; payment_status: string;
  cancellation_status: string; created_at: string;
  lessons: { title: string; start_time: string; end_time: string; price: number } | null;
};
type WaitlistEntry = {
  id: string; lesson_id: string; joined_at: string;
  lessons: { title: string; start_time: string } | null;
};
type Profile = {
  id: string; full_name: string | null; phone: string | null; email: string | null;
  waiver_signed: boolean; stripe_customer_id: string | null;
};

const signupSchema = z.object({
  fullName: z.string().trim().min(2, "Name is too short").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().min(7, "Phone is too short").max(20),
  password: z.string().min(8, "At least 8 characters").max(72),
});

// step -1 = dashboard (returning client), steps 0-4 = new client flow
const STEPS = ["Sign Up", "Player Info", "Waiver", "Select Lesson", "Payment"] as const;

const WAIVER_TEXT = `LIABILITY WAIVER AND RELEASE OF CLAIMS

In consideration of being permitted to participate in tennis lessons, clinics, programs, and related activities ("Activities") offered by Ace Tennis Academy ("Academy"), I, the undersigned participant (or parent/legal guardian of the participant), acknowledge and agree to the following:

1. ASSUMPTION OF RISK. I understand that tennis and related athletic activities involve inherent risks, including but not limited to slips, falls, collisions, sprains, fractures, heat-related illness, and other injuries. I voluntarily assume all such risks.

2. RELEASE OF LIABILITY. I hereby release, waive, and discharge the Academy, its coaches, employees, agents, and affiliates from any and all claims, demands, or causes of action arising out of or related to any loss, damage, or injury sustained during the Activities, except in cases of gross negligence or willful misconduct.

3. MEDICAL TREATMENT. I authorize the Academy to seek emergency medical treatment for the participant if necessary, and I agree to be responsible for any costs incurred.

4. PHOTO/VIDEO RELEASE. I consent to the use of photographs or video taken during Activities for promotional purposes, unless I notify the Academy in writing otherwise.

5. FITNESS REPRESENTATION. I represent that the participant is in good physical condition and has no medical conditions that would prevent safe participation.

6. CANCELLATION POLICY. Cancellations made less than 24 hours before a scheduled lesson will incur a 50% fee. No-shows will be charged the full lesson price.

7. GOVERNING LAW. This waiver shall be governed by the laws of the state in which the Academy operates.

I have read this waiver in its entirety, fully understand its terms, and sign it freely and voluntarily. By typing my name below as a digital signature, I agree this constitutes a legally binding electronic signature.`;

function OnboardingPage() {
  const navigate = useNavigate();
  const signWaiverFn = useServerFn(signWaiver);

  // -1 = dashboard, 0-4 = onboarding steps
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);

  // step 0
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  // step 1
  const [registeringChild, setRegisteringChild] = useState(false);
  const [children, setChildren] = useState<Child[]>([{ name: "", age: "", gender: "" }]);
  const [adult, setAdult] = useState<Child>({ name: "", age: "", gender: "" });
  const [students, setStudents] = useState<Student[]>([]);

  // step 2
  const [agreed, setAgreed] = useState(false);
  const [signature, setSignature] = useState("");

  // step 3
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [lessonsLoading, setLessonsLoading] = useState(false);
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Reload profile — accepts uid so it never has a stale closure
  const reloadProfile = useCallback(async (uid?: string) => {
    const id = uid ?? userId;
    if (!id) return;
    const [{ data: p }, { data: sRows }] = await Promise.all([
      supabase.from("profiles").select("id, full_name, phone, email, waiver_signed, stripe_customer_id").eq("id", id).maybeSingle(),
      supabase.from("students").select("id, name, age, gender").eq("parent_id", id),
    ]);
    if (p) setProfile(p as Profile);
    if (sRows && sRows.length > 0) {
      setStudents(sRows as Student[]);
      setSelectedStudentId((prev) => prev ?? sRows[0].id);
      setRegisteringChild(true);
    }
  }, [userId]);

  // Bootstrap: check existing session
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || cancelled) return;
      setUserId(user.id);
      const [{ data: p }, { data: sRows }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, phone, email, waiver_signed, stripe_customer_id").eq("id", user.id).maybeSingle(),
        supabase.from("students").select("id, name, age, gender").eq("parent_id", user.id),
      ]);
      if (cancelled) return;
      if (p) {
        setProfile(p as Profile);
        setFullName((p as Profile).full_name ?? "");
        setPhone((p as Profile).phone ?? "");
        setEmail((p as Profile).email ?? user.email ?? "");
      }
      if (sRows && sRows.length > 0) {
        setStudents(sRows as Student[]);
        setSelectedStudentId(sRows[0].id);
        setRegisteringChild(true);
      }
      if ((p as Profile | null)?.waiver_signed) {
        setStep(-1);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Load lessons when reaching step 3
  useEffect(() => {
    if (step !== 3) return;
    let cancelled = false;
    (async () => {
      setLessonsLoading(true);
      const nowIso = new Date().toISOString();
      const [{ data: lessonRows, error: lessonErr }, { data: bookingRows }] = await Promise.all([
        supabase.from("lessons").select("id, title, start_time, end_time, capacity, price, lesson_type").gte("start_time", nowIso).order("start_time").limit(60),
        supabase.from("bookings").select("lesson_id").eq("payment_status", "paid").eq("cancellation_status", "active"),
      ]);
      if (cancelled) return;
      if (lessonErr) toast.error(lessonErr.message);
      const counts = new Map<string, number>();
      (bookingRows ?? []).forEach((b) => { counts.set(b.lesson_id, (counts.get(b.lesson_id) ?? 0) + 1); });
      setLessons((lessonRows ?? []).map((l) => ({ ...l, price: Number(l.price), booked: counts.get(l.id) ?? 0 })));
      setLessonsLoading(false);
    })();
    return () => { cancelled = true; };
  }, [step]);

  const updateChild = (i: number, patch: Partial<Child>) => setChildren((arr) => arr.map((c, idx) => idx === i ? { ...c, ...patch } : c));
  const addChild = () => setChildren((a) => [...a, { name: "", age: "", gender: "" }]);
  const removeChild = (i: number) => setChildren((a) => a.filter((_, idx) => idx !== i));
  const selectedLesson = lessons.find((l) => l.id === selectedLessonId) ?? null;

  async function handleSignup() {
    const parsed = signupSchema.safeParse({ fullName, email, phone, password });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error, data: authData } = await supabase.auth.signUp({
      email: parsed.data.email, password: parsed.data.password,
      options: { emailRedirectTo: `${window.location.origin}/onboarding`, data: { full_name: parsed.data.fullName } },
    });
    if (error) { setLoading(false); toast.error(error.message); return; }
    const uid = authData.user?.id;
    if (uid) {
      setUserId(uid);
      await supabase.from("profiles").update({ full_name: parsed.data.fullName, phone: parsed.data.phone, email: parsed.data.email }).eq("id", uid);
      await reloadProfile(uid);
    }
    setLoading(false);
    setStep(1);
  }

  async function handleSignIn(loginEmail: string, loginPassword: string) {
    if (!loginEmail.trim() || !loginPassword) { toast.error("Enter your email and password"); return; }
    setLoading(true);
    const { data: authData, error } = await supabase.auth.signInWithPassword({ email: loginEmail.trim(), password: loginPassword });
    if (error || !authData.user) { setLoading(false); toast.error(error?.message ?? "Sign in failed"); return; }
    const uid = authData.user.id;
    setUserId(uid);
    await reloadProfile(uid);
    setLoading(false);
    const { data: p } = await supabase.from("profiles").select("waiver_signed").eq("id", uid).maybeSingle();
    if (p?.waiver_signed) {
      toast.success("Welcome back! Pick your next lesson.");
      setStep(-1);
    } else {
      toast.success("Signed in. Let's finish setting you up.");
      setStep(1);
    }
  }

  async function handlePlayerInfo() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("Session expired"); return; }

    if (registeringChild) {
      const valid = children.filter((c) => c.name.trim());
      if (valid.length === 0) { toast.error("Add at least one child or uncheck the box"); return; }
      setLoading(true);
      // Avoid duplicating existing students
      const { data: existing } = await supabase.from("students").select("name").eq("parent_id", user.id);
      const existingNames = new Set((existing ?? []).map((s: { name: string }) => s.name.toLowerCase()));
      const newRows = valid.filter((c) => !existingNames.has(c.name.trim().toLowerCase())).map((c) => ({
        parent_id: user.id,
        name: c.name.trim().slice(0, 100),
        age: c.age ? Math.max(1, Math.min(100, parseInt(c.age, 10) || 0)) : null,
        gender: c.gender ? c.gender.slice(0, 30) : null,
      }));
      if (newRows.length > 0) {
        const { data: inserted, error } = await supabase.from("students").insert(newRows).select("id, name, age, gender");
        if (error) { setLoading(false); toast.error(error.message); return; }
        const allStudents = [...students, ...(inserted ?? []) as Student[]];
        setStudents(allStudents);
        if (allStudents.length > 0) setSelectedStudentId(allStudents[0].id);
      }
      setLoading(false);
    } else {
      if (!adult.name.trim()) { toast.error("Please enter your full name"); return; }
      setLoading(true);
      const { error } = await supabase.from("profiles").update({ full_name: adult.name.trim().slice(0, 100) }).eq("id", user.id);
      setLoading(false);
      if (error) { toast.error(error.message); return; }
      setFullName(adult.name.trim());
      setStudents([]);
      setSelectedStudentId(null);
    }
    setStep(2);
  }

  async function handleWaiver() {
    if (!agreed) { toast.error("You must agree to the terms"); return; }
    if (signature.trim().length < 2) { toast.error("Please type your full name as signature"); return; }
    setLoading(true);
    try {
      await signWaiverFn({ data: { signature: signature.trim().slice(0, 100) } });
      const uid = userId;
      if (uid) await reloadProfile(uid);
      setStep(-1);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not sign waiver");
    } finally {
      setLoading(false);
    }
  }

  function handleConfirmLesson() {
    if (!selectedLessonId) { toast.error("Please select a lesson"); return; }
    if (students.length > 0 && !selectedStudentId) { toast.error("Please choose which player this lesson is for"); return; }
    setStep(4);
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  // Dashboard (returning client)
  if (step === -1) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
        <PaymentTestModeBanner />
        <Toaster richColors position="top-center" />
        <header className="border-b border-border bg-background/80 backdrop-blur">
          <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-base">🎾</div>
              <div className="text-sm font-bold">Ace Tennis</div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleSignOut}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </Button>
          </div>
        </header>
        <div className="mx-auto max-w-2xl px-4 py-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">Welcome back{profile?.full_name ? `, ${profile.full_name.split(" ")[0]}` : ""}!</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your bookings, players, and account.</p>
          </div>
          <Dashboard
            profile={profile}
            students={students}
            userId={userId}
            onReload={() => userId && reloadProfile(userId)}
            onBookLesson={() => setStep(3)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      <PaymentTestModeBanner />
      <Toaster richColors position="top-center" />
      <div className="mx-auto max-w-2xl px-4 py-8 sm:py-12">
        <header className="mb-8 text-center">
          <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg">
            <span className="text-2xl">🎾</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Join Ace Tennis Academy</h1>
          <p className="mt-1 text-sm text-muted-foreground">Get court-ready in a few quick steps</p>
          {userId && step > 0 && (
            <Button variant="ghost" size="sm" className="mt-2" onClick={handleSignOut}>
              <LogOut className="mr-2 h-3 w-3" /> Sign out
            </Button>
          )}
        </header>

        <Stepper step={step} />

        <Card className="mt-6 border-border/60 p-5 shadow-sm sm:p-8">
          {step === 0 && (
            <SignupStep
              fullName={fullName} setFullName={setFullName}
              email={email} setEmail={setEmail}
              phone={phone} setPhone={setPhone}
              password={password} setPassword={setPassword}
              onNext={handleSignup} onSignIn={handleSignIn} loading={loading}
            />
          )}
          {step === 1 && (
            <PlayerStep
              registeringChild={registeringChild} setRegisteringChild={setRegisteringChild}
              children={children} updateChild={updateChild} addChild={addChild} removeChild={removeChild}
              adult={adult} setAdult={setAdult}
              onBack={() => setStep(0)} onNext={handlePlayerInfo} loading={loading}
            />
          )}
          {step === 2 && (
            <WaiverStep
              agreed={agreed} setAgreed={setAgreed}
              signature={signature} setSignature={setSignature}
              onBack={() => setStep(1)} onNext={handleWaiver} loading={loading}
            />
          )}
          {step === 3 && (
            <LessonStep
              lessons={lessons} loading={lessonsLoading}
              selectedLessonId={selectedLessonId} setSelectedLessonId={setSelectedLessonId}
              students={students}
              selectedStudentId={selectedStudentId} setSelectedStudentId={setSelectedStudentId}
              onBack={() => (profile?.waiver_signed ? setStep(-1) : setStep(2))}
              onNext={handleConfirmLesson}
            />
          )}
          {step === 4 && selectedLesson && (
            <PaymentStep
              lesson={selectedLesson}
              studentId={selectedStudentId}
              onBack={() => setStep(3)}
            />
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- DASHBOARD */

function Dashboard({ profile, students, userId, onReload, onBookLesson }: {
  profile: Profile | null; students: Student[]; userId: string | null;
  onReload: () => void; onBookLesson: () => void;
}) {
  return (
    <Tabs defaultValue="lessons">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="lessons">Lessons</TabsTrigger>
        <TabsTrigger value="players">Players</TabsTrigger>
        <TabsTrigger value="account">Account</TabsTrigger>
      </TabsList>
      <TabsContent value="lessons" className="mt-4">
        <LessonsTab userId={userId} onBookLesson={onBookLesson} />
      </TabsContent>
      <TabsContent value="players" className="mt-4">
        <PlayersTab students={students} userId={userId} onReload={onReload} />
      </TabsContent>
      <TabsContent value="account" className="mt-4">
        <AccountTab profile={profile} onReload={onReload} />
      </TabsContent>
    </Tabs>
  );
}

function LessonsTab({ userId, onBookLesson }: { userId: string | null; onBookLesson: () => void }) {
  const cancelFn = useServerFn(cancelMyBooking);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [waitlist, setWaitlist] = useState<WaitlistEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelTarget, setCancelTarget] = useState<Booking | null>(null);
  const [canceling, setCanceling] = useState(false);

  async function load() {
    if (!userId) return;
    setLoading(true);
    const [{ data: b }, { data: w }] = await Promise.all([
      supabase.from("bookings").select("id, lesson_id, payment_status, cancellation_status, created_at, lessons(title, start_time, end_time, price)").eq("profile_id", userId).order("created_at", { ascending: false }),
      supabase.from("waitlist").select("id, lesson_id, joined_at, lessons(title, start_time)").eq("profile_id", userId).order("joined_at", { ascending: false }),
    ]);
    setBookings((b ?? []) as unknown as Booking[]);
    setWaitlist((w ?? []) as unknown as WaitlistEntry[]);
    setLoading(false);
  }

  useEffect(() => { load(); }, [userId]);

  async function handleCancel(booking: Booking) {
    setCanceling(true);
    try {
      const result = await cancelFn({ data: { bookingId: booking.id } });
      if (!result.ok) { toast.error(result.error ?? "Cancel failed"); return; }
      if (result.outcome === "refunded") toast.success("Booking canceled. Full refund issued.");
      else if (result.outcome === "penalty_charged") toast.warning("Booking canceled. 50% late-cancel fee charged.");
      else toast.success("Booking canceled.");
      setCancelTarget(null);
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Cancel failed");
    } finally {
      setCanceling(false);
    }
  }

  async function leaveWaitlist(id: string) {
    const { error } = await supabase.from("waitlist").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Removed from waitlist");
    load();
  }

  if (loading) return <div className="py-8 text-center text-sm text-muted-foreground">Loading…</div>;

  const now = new Date();
  const upcoming = bookings.filter((b) => b.cancellation_status !== "canceled" && b.lessons && new Date(b.lessons.start_time) >= now);
  const past = bookings.filter((b) => b.cancellation_status !== "canceled" && b.lessons && new Date(b.lessons.start_time) < now);

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Upcoming lessons</h3>
          <Button size="sm" onClick={onBookLesson}><Plus className="mr-1 h-3 w-3" /> Book a lesson</Button>
        </div>

        {upcoming.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
            No upcoming lessons.{" "}
            <button onClick={onBookLesson} className="text-primary underline">Book one now →</button>
          </div>
        ) : (
          <div className="space-y-2">
            {upcoming.map((b) => {
              if (!b.lessons) return null;
              const start = new Date(b.lessons.start_time);
              const hoursUntil = (start.getTime() - now.getTime()) / 3_600_000;
              const isLateCancelWindow = hoursUntil < 24;
              return (
                <div key={b.id} className="rounded-lg border border-border bg-background p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{b.lessons.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {start.toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                      </div>
                      <div className="text-xs text-muted-foreground">${Number(b.lessons.price).toFixed(2)}</div>
                    </div>
                    <Button size="sm" variant="outline" className="text-destructive hover:text-destructive h-7 text-xs" onClick={() => setCancelTarget(b)}>
                      Cancel
                    </Button>
                  </div>
                  {isLateCancelWindow && (
                    <div className="mt-2 rounded-md bg-orange-50 border border-orange-200 px-2 py-1 text-xs text-orange-700">
                      ⚠️ Canceling within 24h will incur a 50% fee
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {waitlist.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-semibold">Waitlist</h3>
            {waitlist.map((w) => (
              <div key={w.id} className="rounded-lg border border-border bg-secondary/30 p-3 flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-medium">{w.lessons?.title ?? "Lesson"}</div>
                  <div className="text-xs text-muted-foreground">
                    {w.lessons ? new Date(w.lessons.start_time).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }) : ""}
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="h-7 text-xs text-muted-foreground hover:text-destructive" onClick={() => leaveWaitlist(w.id)}>
                  Leave
                </Button>
              </div>
            ))}
          </div>
        )}

        {past.length > 0 && (
          <details className="mt-4">
            <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">Past lessons ({past.length})</summary>
            <div className="mt-2 space-y-2">
              {past.map((b) => (
                <div key={b.id} className="rounded-lg border border-border bg-background p-3 opacity-60">
                  <div className="text-sm font-medium">{b.lessons?.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {b.lessons ? new Date(b.lessons.start_time).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }) : ""}
                    {" · "}{b.payment_status}
                  </div>
                </div>
              ))}
            </div>
          </details>
        )}
      </div>

      <AlertDialog open={!!cancelTarget} onOpenChange={(v) => !v && setCancelTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel this booking?</AlertDialogTitle>
            <AlertDialogDescription>
              {cancelTarget && (() => {
                const start = new Date(cancelTarget.lessons?.start_time ?? "");
                const h = (start.getTime() - now.getTime()) / 3_600_000;
                return h < 24
                  ? "This is within 24 hours of the lesson. A 50% cancellation fee will be charged."
                  : "You'll receive a full refund since it's more than 24 hours before the lesson.";
              })()}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep booking</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => cancelTarget && handleCancel(cancelTarget)} disabled={canceling}>
              {canceling ? "Canceling…" : "Cancel booking"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function PlayersTab({ students, userId, onReload }: { students: Student[]; userId: string | null; onReload: () => void }) {
  const [list, setList] = useState<Student[]>(students);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);

  useEffect(() => { setList(students); }, [students]);

  async function loadStudents() {
    if (!userId) return;
    const { data } = await supabase.from("students").select("id, name, age, gender").eq("parent_id", userId);
    setList((data ?? []) as Student[]);
    onReload();
  }

  async function deleteStudent(s: Student) {
    const { error } = await supabase.from("students").delete().eq("id", s.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Player removed");
    setDeleteTarget(null);
    loadStudents();
  }

  return (
    <>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Registered players</h3>
          <Button size="sm" onClick={() => { setEditingStudent(null); setDialogOpen(true); }}>
            <Plus className="mr-1 h-3 w-3" /> Add player
          </Button>
        </div>
        {list.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
            No players registered yet.
          </div>
        ) : (
          list.map((s) => (
            <div key={s.id} className="rounded-lg border border-border bg-background p-3 flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">{s.name}</div>
                <div className="text-xs text-muted-foreground">{s.age != null ? `Age ${s.age}` : "—"}{s.gender ? ` • ${s.gender}` : ""}</div>
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditingStudent(s); setDialogOpen(true); }}>
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => setDeleteTarget(s)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      <PlayerDialog
        open={dialogOpen} onOpenChange={setDialogOpen}
        student={editingStudent} parentId={userId ?? ""}
        onSaved={() => { setDialogOpen(false); setEditingStudent(null); loadStudents(); }}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {deleteTarget?.name}?</AlertDialogTitle>
            <AlertDialogDescription>This will remove the player from your account.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteTarget && deleteStudent(deleteTarget)}>
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function PlayerDialog({ open, onOpenChange, student, parentId, onSaved }: {
  open: boolean; onOpenChange: (v: boolean) => void; student: Student | null; parentId: string; onSaved: () => void;
}) {
  const isEdit = !!student;
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (student) { setName(student.name); setAge(student.age != null ? String(student.age) : ""); setGender(student.gender ?? ""); }
    else { setName(""); setAge(""); setGender(""); }
  }, [student, open]);

  async function submit() {
    if (!name.trim()) { toast.error("Name is required"); return; }
    setBusy(true);
    const payload = { name: name.trim(), age: age ? parseInt(age, 10) : null, gender: gender || null };
    if (isEdit && student) {
      const { error } = await supabase.from("students").update(payload).eq("id", student.id);
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      toast.success("Player updated");
    } else {
      const { error } = await supabase.from("students").insert({ ...payload, parent_id: parentId });
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      toast.success("Player added");
    }
    onSaved();
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{isEdit ? "Edit player" : "Add player"}</AlertDialogTitle>
        </AlertDialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Age</Label>
              <Input type="number" min={1} max={100} value={age} onChange={(e) => setAge(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Gender</Label>
              <select value={gender} onChange={(e) => setGender(e.target.value)} className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm">
                <option value="">—</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="other">Other</option>
                <option value="prefer_not_to_say">Prefer not to say</option>
              </select>
            </div>
          </div>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={submit} disabled={busy}>{busy ? "Saving…" : (isEdit ? "Save" : "Add")}</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function AccountTab({ profile, onReload }: { profile: Profile | null; onReload: () => void }) {
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState(profile?.full_name ?? "");
  const [editPhone, setEditPhone] = useState(profile?.phone ?? "");
  const [saving, setSaving] = useState(false);

  // Keep local state in sync after saves
  useEffect(() => {
    if (!editing) {
      setEditName(profile?.full_name ?? "");
      setEditPhone(profile?.phone ?? "");
    }
  }, [profile, editing]);

  async function saveProfile() {
    if (!profile?.id) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ full_name: editName.trim(), phone: editPhone.trim() }).eq("id", profile.id);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Profile updated");
    setEditing(false);
    onReload();
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            {editing ? (
              <div className="space-y-2">
                <div className="space-y-1.5">
                  <Label>Full name</Label>
                  <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Phone</Label>
                  <Input value={editPhone} onChange={(e) => setEditPhone(e.target.value)} />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={saveProfile} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
                  <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div>
                <div className="font-semibold">{profile?.full_name || "Unnamed"}</div>
                <div className="text-sm text-muted-foreground">{profile?.email}</div>
                <div className="text-sm text-muted-foreground">{profile?.phone || "No phone"}</div>
              </div>
            )}
          </div>
          {!editing && (
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditing(true)}>
              <Pencil className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm font-medium">Liability waiver</div>
          {profile?.waiver_signed ? (
            <Badge className="gap-1"><CheckCircle2 className="h-3 w-3" /> Signed</Badge>
          ) : (
            <Badge variant="destructive">Not signed</Badge>
          )}
        </div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ STEPPER */

function Stepper({ step }: { step: number }) {
  return (
    <div className="flex items-center justify-between gap-1 sm:gap-2">
      {STEPS.map((label, i) => {
        const active = i === step;
        const done = i < step;
        return (
          <div key={label} className="flex flex-1 flex-col items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border-2 text-sm font-semibold transition-all ${done ? "border-primary bg-primary text-primary-foreground" : active ? "border-primary bg-background text-primary scale-110" : "border-border bg-background text-muted-foreground"}`}>
              {done ? <CheckCircle2 className="h-5 w-5" /> : i + 1}
            </div>
            <span className={`text-[10px] font-medium uppercase tracking-wide sm:text-xs ${active ? "text-foreground" : "text-muted-foreground"}`}>{label}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------- STEP FORMS */

function SignupStep(props: {
  fullName: string; setFullName: (v: string) => void;
  email: string; setEmail: (v: string) => void;
  phone: string; setPhone: (v: string) => void;
  password: string; setPassword: (v: string) => void;
  onNext: () => void; onSignIn: (email: string, password: string) => void; loading: boolean;
}) {
  const [mode, setMode] = useState<"signup" | "login">("signup");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  if (mode === "login") {
    return (
      <div className="space-y-5">
        <div>
          <h2 className="text-xl font-bold">Welcome back</h2>
          <p className="text-sm text-muted-foreground">Sign in to book your next lesson.</p>
        </div>
        <Field id="loginEmail" label="Email" type="email" value={loginEmail} onChange={setLoginEmail} placeholder="you@example.com" />
        <Field id="loginPassword" label="Password" type="password" value={loginPassword} onChange={setLoginPassword} placeholder="Your password" />
        <Button onClick={() => props.onSignIn(loginEmail, loginPassword)} disabled={props.loading} className="w-full" size="lg">
          {props.loading ? "Signing in..." : "Log In"}
        </Button>
        <p className="text-center text-sm text-muted-foreground">
          New here?{" "}
          <button type="button" onClick={() => setMode("signup")} className="font-medium text-primary hover:underline">Create an account</button>
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold">Create your account</h2>
        <p className="text-sm text-muted-foreground">Let's get you signed up.</p>
      </div>
      <Field id="fullName" label="Full Name" value={props.fullName} onChange={props.setFullName} placeholder="Jane Doe" />
      <Field id="email" label="Email" type="email" value={props.email} onChange={props.setEmail} placeholder="you@example.com" />
      <Field id="phone" label="Phone Number" type="tel" value={props.phone} onChange={props.setPhone} placeholder="(555) 123-4567" />
      <Field id="password" label="Password" type="password" value={props.password} onChange={props.setPassword} placeholder="At least 8 characters" />
      <Button onClick={props.onNext} disabled={props.loading} className="w-full" size="lg">
        {props.loading ? "Creating account..." : "Continue"}
      </Button>
      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <button type="button" onClick={() => setMode("login")} className="font-medium text-primary hover:underline">Sign in</button>
      </p>
    </div>
  );
}

function PlayerStep(props: {
  registeringChild: boolean; setRegisteringChild: (v: boolean) => void;
  children: Child[]; updateChild: (i: number, p: Partial<Child>) => void;
  addChild: () => void; removeChild: (i: number) => void;
  adult: Child; setAdult: (v: Child) => void;
  onBack: () => void; onNext: () => void; loading: boolean;
}) {
  const genderOptions = (
    <>
      <option value="">—</option>
      <option value="female">Female</option>
      <option value="male">Male</option>
      <option value="other">Other</option>
      <option value="prefer_not_to_say">Prefer not to say</option>
    </>
  );
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold">{props.registeringChild ? "Player information" : "Adult Player Information"}</h2>
        <p className="text-sm text-muted-foreground">Tell us who's hitting the court.</p>
      </div>
      <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-border bg-secondary/40 p-4 transition-colors hover:bg-secondary/70">
        <Checkbox id="isChild" checked={props.registeringChild} onCheckedChange={(v) => props.setRegisteringChild(v === true)} className="mt-0.5" />
        <div>
          <div className="font-medium">Are you registering a child?</div>
          <div className="text-sm text-muted-foreground">Check this if the player is under 18.</div>
        </div>
      </label>
      {props.registeringChild ? (
        <div className="space-y-4">
          {props.children.map((c, i) => (
            <div key={i} className="space-y-3 rounded-lg border border-border bg-background p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">Child {i + 1}</h3>
                {props.children.length > 1 && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => props.removeChild(i)}><Trash2 className="h-4 w-4" /></Button>
                )}
              </div>
              <Field id={`cn-${i}`} label="Child's Name" value={c.name} onChange={(v) => props.updateChild(i, { name: v })} placeholder="Required" />
              <div className="grid grid-cols-2 gap-3">
                <Field id={`ca-${i}`} label="Age" type="number" value={c.age} onChange={(v) => props.updateChild(i, { age: v })} placeholder="Optional" />
                <div className="space-y-1.5">
                  <Label htmlFor={`cg-${i}`}>Gender</Label>
                  <select id={`cg-${i}`} value={c.gender} onChange={(e) => props.updateChild(i, { gender: e.target.value })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">{genderOptions}</select>
                </div>
              </div>
            </div>
          ))}
          <Button type="button" variant="outline" onClick={props.addChild} className="w-full"><Plus className="mr-2 h-4 w-4" /> Add Another Child</Button>
        </div>
      ) : (
        <div className="space-y-3 rounded-lg border border-border bg-background p-4">
          <Field id="adult-name" label="Full Name" value={props.adult.name} onChange={(v) => props.setAdult({ ...props.adult, name: v })} placeholder="Jane Doe" />
          <div className="grid grid-cols-2 gap-3">
            <Field id="adult-age" label="Age" type="number" value={props.adult.age} onChange={(v) => props.setAdult({ ...props.adult, age: v })} placeholder="e.g. 32" />
            <div className="space-y-1.5">
              <Label htmlFor="adult-gender">Gender</Label>
              <select id="adult-gender" value={props.adult.gender} onChange={(e) => props.setAdult({ ...props.adult, gender: e.target.value })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">{genderOptions}</select>
            </div>
          </div>
        </div>
      )}
      <NavRow onBack={props.onBack} onNext={props.onNext} loading={props.loading} />
    </div>
  );
}

function WaiverStep(props: {
  agreed: boolean; setAgreed: (v: boolean) => void;
  signature: string; setSignature: (v: string) => void;
  onBack: () => void; onNext: () => void; loading: boolean;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold">Liability waiver</h2>
        <p className="text-sm text-muted-foreground">Please read carefully before signing.</p>
      </div>
      <div className="h-64 overflow-y-auto rounded-lg border border-border bg-secondary/30 p-4 text-sm leading-relaxed text-muted-foreground whitespace-pre-wrap">{WAIVER_TEXT}</div>
      <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-border p-3 hover:bg-secondary/40">
        <Checkbox id="agree" checked={props.agreed} onCheckedChange={(v) => props.setAgreed(v === true)} className="mt-0.5" />
        <span className="text-sm font-medium">I agree to the terms</span>
      </label>
      <div className="space-y-1.5">
        <Label htmlFor="sig">Digital signature</Label>
        <Input id="sig" value={props.signature} onChange={(e) => props.setSignature(e.target.value)} placeholder="Type your full legal name" className="font-serif italic text-lg" maxLength={100} />
      </div>
      <NavRow onBack={props.onBack} onNext={props.onNext} loading={props.loading} />
    </div>
  );
}

function LessonStep(props: {
  lessons: Lesson[]; loading: boolean;
  selectedLessonId: string | null; setSelectedLessonId: (v: string) => void;
  students: Student[];
  selectedStudentId: string | null; setSelectedStudentId: (v: string) => void;
  onBack: () => void; onNext: () => void;
}) {
  const [view, setView] = useState<"calendar" | "list">("calendar");
  const [waitlistJoining, setWaitlistJoining] = useState<string | null>(null);
  const [waitlistedIds, setWaitlistedIds] = useState<Set<string>>(new Set());

  const selected = props.lessons.find((l) => l.id === props.selectedLessonId) ?? null;

  async function joinWaitlist(lessonId: string) {
    setWaitlistJoining(lessonId);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { toast.error("Please sign in first"); return; }
      const { error } = await supabase.from("waitlist").insert({ lesson_id: lessonId, profile_id: user.id, student_id: props.selectedStudentId });
      if (error) { toast.error(error.message); return; }
      setWaitlistedIds((s) => new Set(s).add(lessonId));
      toast.success("You're on the waitlist!");
    } finally {
      setWaitlistJoining(null);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Pick a lesson</h2>
          <p className="text-sm text-muted-foreground">Choose an available time slot to book.</p>
        </div>
        <ToggleGroup type="single" value={view} onValueChange={(v) => v && setView(v as "calendar" | "list")} variant="outline" size="sm" className="bg-secondary/40 rounded-md p-0.5">
          <ToggleGroupItem value="calendar" className="gap-1.5"><CalendarRange className="h-4 w-4" /> Calendar</ToggleGroupItem>
          <ToggleGroupItem value="list" className="gap-1.5"><LayoutGrid className="h-4 w-4" /> List</ToggleGroupItem>
        </ToggleGroup>
      </div>

      {props.students.length > 0 && (
        <div className="space-y-2 rounded-lg border border-border bg-secondary/30 p-3">
          <Label className="text-xs uppercase tracking-wide text-muted-foreground">Player</Label>
          <select value={props.selectedStudentId ?? ""} onChange={(e) => props.setSelectedStudentId(e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
            {props.students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
      )}

      {props.loading ? (
        <div className="py-10 text-center text-sm text-muted-foreground">Loading lessons…</div>
      ) : props.lessons.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No upcoming lessons available yet.</div>
      ) : view === "calendar" ? (
        <MonthCalendar
          lessons={props.lessons}
          selectedLessonId={props.selectedLessonId}
          onSelect={props.setSelectedLessonId}
          onJoinWaitlist={joinWaitlist}
          waitlistJoining={waitlistJoining}
          waitlistedIds={waitlistedIds}
        />
      ) : (
        <ListView
          lessons={props.lessons}
          selectedLessonId={props.selectedLessonId}
          onSelect={props.setSelectedLessonId}
          onJoinWaitlist={joinWaitlist}
          waitlistJoining={waitlistJoining}
          waitlistedIds={waitlistedIds}
        />
      )}

      {selected && (
        <div className="rounded-lg border-2 border-primary/40 bg-primary/5 p-4">
          <div className="text-xs uppercase tracking-wide text-primary/80 font-semibold">Selected</div>
          <div className="mt-1 flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="font-semibold truncate">{selected.title}</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {new Date(selected.start_time).toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} – {new Date(selected.end_time).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
              </div>
            </div>
            <div className="text-lg font-bold text-primary">${selected.price.toFixed(2)}</div>
          </div>
        </div>
      )}

      <NavRow onBack={props.onBack} onNext={props.onNext} loading={false} nextLabel="Continue to payment" />
    </div>
  );
}

/* --------------------------------------------------------- MONTHLY CALENDAR */

function MonthCalendar({ lessons, selectedLessonId, onSelect, onJoinWaitlist, waitlistJoining, waitlistedIds }: {
  lessons: Lesson[]; selectedLessonId: string | null; onSelect: (id: string) => void;
  onJoinWaitlist: (id: string) => void; waitlistJoining: string | null; waitlistedIds: Set<string>;
}) {
  const [calDate, setCalDate] = useState<Date>(() => {
    // Start on month of first lesson if it's in the future
    const first = lessons[0];
    if (!first) return new Date();
    const d = new Date(first.start_time);
    const now = new Date();
    return d > now ? new Date(d.getFullYear(), d.getMonth(), 1) : new Date(now.getFullYear(), now.getMonth(), 1);
  });

  // Advance to first lesson month when lessons load
  useEffect(() => {
    if (lessons.length === 0) return;
    const first = new Date(lessons[0].start_time);
    const now = new Date();
    if (first > now) {
      setCalDate(new Date(first.getFullYear(), first.getMonth(), 1));
    }
  }, [lessons]);

  const year = calDate.getFullYear();
  const month = calDate.getMonth();

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  // Monday-based: 0=Mon .. 6=Sun
  const startOffset = (firstDay.getDay() + 6) % 7;
  const totalCells = startOffset + lastDay.getDate();
  const rows = Math.ceil(totalCells / 7);

  const lessonsByDay: Record<string, Lesson[]> = {};
  lessons.forEach((l) => {
    const d = new Date(l.start_time);
    if (d.getFullYear() === year && d.getMonth() === month) {
      const key = d.getDate().toString();
      (lessonsByDay[key] ??= []).push(l);
    }
  });

  function prevMonth() { setCalDate(new Date(year, month - 1, 1)); }
  function nextMonth() { setCalDate(new Date(year, month + 1, 1)); }

  const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={prevMonth}><ChevronLeft className="h-4 w-4" /></Button>
        <div className="text-sm font-semibold">{firstDay.toLocaleDateString(undefined, { month: "long", year: "numeric" })}</div>
        <Button variant="ghost" size="icon" onClick={nextMonth}><ChevronRight className="h-4 w-4" /></Button>
      </div>

      <div className="overflow-x-auto -mx-1 px-1">
        <div className="min-w-[560px]">
          {/* Day labels */}
          <div className="grid grid-cols-7 mb-1">
            {DAY_LABELS.map((d) => (
              <div key={d} className="text-center text-[10px] uppercase tracking-wide text-muted-foreground py-1">{d}</div>
            ))}
          </div>

          {/* Calendar grid */}
          {Array.from({ length: rows }, (_, r) => (
            <div key={r} className="grid grid-cols-7 gap-0.5 mb-0.5">
              {Array.from({ length: 7 }, (_, c) => {
                const cellIndex = r * 7 + c;
                const dayNum = cellIndex - startOffset + 1;
                const isValid = dayNum >= 1 && dayNum <= lastDay.getDate();
                const dayLessons = isValid ? (lessonsByDay[dayNum.toString()] ?? []) : [];
                const isToday = isValid && new Date(year, month, dayNum).toDateString() === new Date().toDateString();

                return (
                  <div key={c} className={`min-h-[80px] rounded border border-border/50 p-1 ${!isValid ? "bg-muted/20" : "bg-background"}`}>
                    {isValid && (
                      <>
                        <div className={`text-xs font-medium mb-1 w-5 h-5 flex items-center justify-center rounded-full ${isToday ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                          {dayNum}
                        </div>
                        <div className="space-y-0.5">
                          {dayLessons.slice(0, 2).map((l) => {
                            const isFull = l.booked >= l.capacity;
                            const isSelected = l.id === selectedLessonId;
                            const waitlisted = waitlistedIds.has(l.id);
                            const time = new Date(l.start_time).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });

                            if (isFull) {
                              return (
                                <div key={l.id} className="rounded bg-muted/60 p-1 text-[9px]">
                                  <div className="font-medium text-muted-foreground truncate">{time} {l.title}</div>
                                  {waitlisted ? (
                                    <div className="text-primary font-medium">✓ Waitlisted</div>
                                  ) : (
                                    <button onClick={() => onJoinWaitlist(l.id)} disabled={waitlistJoining === l.id} className="text-primary hover:underline disabled:opacity-50">
                                      {waitlistJoining === l.id ? "…" : "+ Waitlist"}
                                    </button>
                                  )}
                                </div>
                              );
                            }

                            return (
                              <button
                                key={l.id}
                                onClick={() => onSelect(l.id)}
                                className={`w-full rounded p-1 text-[9px] text-left transition-all ${isSelected ? "bg-primary text-primary-foreground" : "bg-primary/10 hover:bg-primary/20 text-foreground"}`}
                              >
                                <div className="font-semibold truncate">{time}</div>
                                <div className="truncate">{l.title}</div>
                                <div className={isSelected ? "text-primary-foreground/80" : "text-muted-foreground"}>${l.price.toFixed(0)} · {l.booked}/{l.capacity}</div>
                              </button>
                            );
                          })}
                          {dayLessons.length > 2 && (
                            <div className="text-[9px] text-muted-foreground pl-1">+{dayLessons.length - 2} more</div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- LIST VIEW */

function ListView({ lessons, selectedLessonId, onSelect, onJoinWaitlist, waitlistJoining, waitlistedIds }: {
  lessons: Lesson[]; selectedLessonId: string | null; onSelect: (id: string) => void;
  onJoinWaitlist: (id: string) => void; waitlistJoining: string | null; waitlistedIds: Set<string>;
}) {
  return (
    <div className="space-y-2">
      {lessons.map((l) => {
        const isFull = l.booked >= l.capacity;
        const isSelected = l.id === selectedLessonId;
        const date = new Date(l.start_time);
        const end = new Date(l.end_time);
        const waitlisted = waitlistedIds.has(l.id);

        if (isFull) {
          return (
            <div key={l.id} className="rounded-lg border-2 border-border bg-muted/40 p-4 opacity-70">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="font-semibold truncate">{l.title}</div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <CalendarDays className="h-3.5 w-3.5" />
                    {date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} · {date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })} – {end.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Users className="h-3.5 w-3.5" />{l.booked}/{l.capacity} booked
                    <span className="font-semibold text-destructive">Full</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-0.5 text-lg font-bold text-muted-foreground"><DollarSign className="h-4 w-4" />{l.price.toFixed(2)}</div>
                  {waitlisted ? (
                    <div className="mt-1 text-xs font-medium text-primary">✓ On waitlist</div>
                  ) : (
                    <button onClick={() => onJoinWaitlist(l.id)} disabled={waitlistJoining === l.id} className="mt-1 text-xs font-medium text-primary hover:underline disabled:opacity-50">
                      {waitlistJoining === l.id ? "Joining…" : "Join Waitlist"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        }

        return (
          <button
            key={l.id}
            type="button"
            onClick={() => onSelect(l.id)}
            className={`w-full rounded-lg border-2 p-4 text-left transition-all ${isSelected ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:border-primary/40 hover:bg-secondary/30"}`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="font-semibold truncate">{l.title}</div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} · {date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })} – {end.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Users className="h-3.5 w-3.5" />{l.booked}/{l.capacity} booked
                </div>
              </div>
              <div className="flex items-center gap-0.5 text-lg font-bold text-primary"><DollarSign className="h-4 w-4" />{l.price.toFixed(2)}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ----------------------------------------------------------- PAYMENT STEP */

function PaymentStep(props: { lesson: Lesson; studentId: string | null; onBack: () => void; }) {
  const getRosterFn = useServerFn(getMatchPlayRoster);
  const [stayForMatchPlay, setStayForMatchPlay] = useState(false);
  const [roster, setRoster] = useState<string[]>([]);
  const isMorningMix = props.lesson.lesson_type === "mens_womens_morning_mix";

  useEffect(() => {
    if (!isMorningMix || !stayForMatchPlay) { setRoster([]); return; }
    getRosterFn({ data: { lessonId: props.lesson.id } }).then((r) => setRoster(r.roster)).catch(() => {});
  }, [isMorningMix, stayForMatchPlay, props.lesson.id]);

  const date = new Date(props.lesson.start_time);
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold">Secure payment</h2>
        <p className="text-sm text-muted-foreground">Complete your booking below.</p>
      </div>

      <div className="rounded-lg border border-border bg-secondary/30 p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Booking</div>
        <div className="mt-1 font-semibold">{props.lesson.title}</div>
        <div className="text-sm text-muted-foreground">{date.toLocaleString(undefined, { weekday: "long", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div>
        <div className="mt-2 text-2xl font-bold">${props.lesson.price.toFixed(2)}</div>
      </div>

      {isMorningMix && (
        <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-border bg-secondary/20 p-3 hover:bg-secondary/40">
          <Checkbox checked={stayForMatchPlay} onCheckedChange={(v) => setStayForMatchPlay(v === true)} className="mt-0.5" />
          <div className="text-sm">
            <div className="font-medium">Staying after for organized match play?</div>
            <div className="text-xs text-muted-foreground">We'll let other adults know you're sticking around.</div>
          </div>
        </label>
      )}

      {isMorningMix && stayForMatchPlay && roster.length > 0 && (
        <div className="rounded-lg border border-border bg-secondary/20 p-3">
          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Others staying for match play</div>
          <div className="flex flex-wrap gap-1.5">
            {roster.map((name, i) => <Badge key={i} variant="secondary">{name}</Badge>)}
          </div>
        </div>
      )}

      <div className="rounded-lg border-2 border-accent bg-accent/15 p-4">
        <div className="flex gap-3">
          <AlertTriangle className="h-5 w-5 flex-shrink-0 text-accent-foreground" />
          <div className="text-sm">
            <div className="font-semibold text-accent-foreground">⚠️ Cancellation Policy</div>
            <p className="mt-1 text-accent-foreground/90">Cancellations made less than 24 hours before your scheduled lesson will incur a 50% fee.</p>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-background overflow-hidden">
        <LessonCheckout lessonId={props.lesson.id} studentId={props.studentId} stayForMatchPlay={stayForMatchPlay} />
      </div>

      <Button onClick={props.onBack} variant="ghost" className="w-full">← Choose a different lesson</Button>
    </div>
  );
}

/* ------------------------------------------------------------- SHARED UI */

function Field({ id, label, value, onChange, placeholder, type = "text" }: {
  id: string; label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

function NavRow({ onBack, onNext, loading, nextLabel }: { onBack: () => void; onNext: () => void; loading: boolean; nextLabel?: string }) {
  return (
    <div className="flex gap-3 pt-2">
      <Button variant="outline" onClick={onBack} disabled={loading} className="flex-1">Back</Button>
      <Button onClick={onNext} disabled={loading} className="flex-1">{loading ? "Saving..." : (nextLabel ?? "Continue")}</Button>
    </div>
  );
}
